import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { REGISTERPAGEComponent } from './register-page.component';

describe('REGISTERPAGEComponent', () => {
  let component: REGISTERPAGEComponent;
  let fixture: ComponentFixture<REGISTERPAGEComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ REGISTERPAGEComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(REGISTERPAGEComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
